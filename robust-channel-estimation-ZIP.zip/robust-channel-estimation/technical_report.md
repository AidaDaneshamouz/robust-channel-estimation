# Robust Channel Estimation in Digital Communications
Student Name: Aida Daneshamouz

University: Sharif University of Technology
## Abstract

Channel estimation is an essential task in digital communication systems because the receiver needs an estimate of the communication channel to recover transmitted information reliably. Conventional Least Squares (LS) estimation is simple and computationally efficient, but it can be sensitive to impulsive noise and outliers. This project investigates robust channel estimation methods by comparing LS, Huber, and Median estimators in a simulated digital communication system.

A real-valued flat-fading channel with BPSK pilot symbols is considered. The estimators are evaluated under Gaussian noise and impulsive noise using estimation error metrics, including Mean Absolute Error (MAE) and Mean Squared Error (MSE). Additional experiments investigate the effects of noise strength, pilot length, Huber threshold, signal-to-noise ratio (SNR), and impulsive-noise probability. Bit Error Rate (BER) is also evaluated for BPSK transmission.

The simulation results demonstrate that robust estimators can substantially reduce channel-estimation errors in the presence of impulsive noise. In particular, Huber estimation provides strong performance under the tested impulsive-noise conditions.

**Keywords:** Channel Estimation, Least Squares, Huber Estimator, Median Estimator, Impulsive Noise, BPSK, BER, MAE, MSE.

---

## 1. Introduction

Digital communication systems transmit information through channels that may introduce noise and distort the transmitted signals. Accurate channel estimation is therefore important for reliable signal detection and data recovery.

In practical communication environments, noise is not always well described by a Gaussian distribution. Some channels may experience impulsive disturbances that produce unusually large noise samples. These outliers can significantly affect conventional estimation techniques.

The Least Squares estimator is widely used because of its simplicity. However, its squared-error objective gives large deviations considerable influence. Robust estimation methods, such as Huber estimation and Median-based estimation, can reduce the effect of such observations.

The main objective of this project is to compare these three estimation methods and investigate their performance under different noise conditions.

### 1.1 Project Objectives

The main objectives are:

1. Implement LS channel estimation.
2. Implement Huber robust channel estimation.
3. Implement Median-based channel estimation.
4. Compare estimation accuracy under Gaussian and impulsive noise.
5. Evaluate the effect of noise strength and pilot length.
6. Investigate the sensitivity of Huber estimation to its threshold parameter.
7. Compare channel-estimation MSE at different Gaussian SNR values.
8. Investigate the effect of impulsive-noise probability on MSE.
9. Evaluate BPSK detection performance using BER.

---

## 2. System Model

### 2.1 Communication Channel

The project considers a real-valued, flat-fading channel model:

\[
y_k = h x_k + n_k
\]

where:

- \(x_k\) is the transmitted pilot symbol.
- \(y_k\) is the received pilot symbol.
- \(h\) is the unknown channel coefficient.
- \(n_k\) represents additive noise.

The simulation uses the following channel coefficient:

\[
h_{\text{true}}=0.8
\]

BPSK pilot symbols are generated from the set

\[
x_k \in \{-1,+1\}.
\]

The baseline experiment uses 100 pilot symbols and Gaussian noise with standard deviation 0.1.

### 2.2 Noise Model

Two noise components are considered.

**Gaussian noise:** Ordinary additive noise is generated from a zero-mean Gaussian distribution:

\[
n_g \sim \mathcal{N}(0,\sigma_g^2).
\]

**Impulsive noise:** Impulsive disturbances occur randomly with probability \(p\). When an impulse occurs, its amplitude is generated from a zero-mean Gaussian distribution with a larger standard deviation.

The total noise is

\[
n_k=n_{g,k}+n_{i,k},
\]

where \(n_{g,k}\) is Gaussian noise and \(n_{i,k}\) is impulsive noise.

The main impulsive-noise experiments use:

- Gaussian noise standard deviation: 0.1
- Impulsive-noise probability: 0.05
- Impulsive-noise standard deviation: 2.0

These settings produce occasional disturbances whose magnitude can be much larger than that of ordinary Gaussian noise.

---

## 3. Channel Estimation Methods

### 3.1 Least Squares Estimation

The LS estimator estimates the channel coefficient by minimizing the squared difference between the received signal and the channel model.

For the model

\[
y_k=h x_k+n_k,
\]

the LS estimate is

\[
\hat h_{\mathrm{LS}}
=
\frac{\sum_{k=1}^{N}x_k y_k}
{\sum_{k=1}^{N}x_k^2}.
\]

For BPSK pilot symbols, \(x_k^2=1\), so the expression simplifies to

\[
\hat h_{\mathrm{LS}}
=
\frac{1}{N}\sum_{k=1}^{N}x_k y_k.
\]

LS estimation is computationally efficient and performs well under many ordinary noise conditions. However, large noise samples can have a substantial influence on the result.

### 3.2 Huber Robust Estimation

Huber estimation combines quadratic and linear loss behavior. Small residuals are treated using a quadratic loss, while the influence of large residuals is reduced through a linear loss.

The Huber loss function is

\[
\rho_\delta(r)=
\begin{cases}
\frac{1}{2}r^2, & |r|\leq\delta,\\
\delta\left(|r|-\frac{1}{2}\delta\right),
& |r|>\delta.
\end{cases}
\]

Here, \(r\) is the residual and \(\delta\) is the threshold parameter.

The implementation uses an iterative reweighted least squares procedure to obtain the channel estimate. The default threshold is

\[
\delta=1.345.
\]

This method aims to retain good performance for ordinary noise while limiting the influence of unusually large residuals.

### 3.3 Median-Based Estimation

For BPSK pilot symbols, the channel can also be estimated from the products \(x_k y_k\). Since \(x_k\) is either \(-1\) or \(+1\), multiplying by \(x_k\) removes the known pilot sign:

\[
x_k y_k = h+n_kx_k.
\]

The implemented Median estimator is

\[
\hat h_{\mathrm{Median}}
=
\operatorname{median}(x_k y_k).
\]

The median is less sensitive to extreme observations than an ordinary average. Consequently, it can be useful when a limited number of samples are strongly corrupted.

---

## 4. Performance Metrics

### 4.1 Mean Absolute Error

The absolute estimation error in one trial is

\[
e=|\hat h-h_{\text{true}}|.
\]

Across \(T\) trials, the Mean Absolute Error is

\[
\mathrm{MAE}
=
\frac{1}{T}
\sum_{t=1}^{T}
|\hat h_t-h_{\text{true}}|.
\]

A lower MAE indicates that the estimates are closer to the true channel coefficient on average.

### 4.2 Mean Squared Error

The Mean Squared Error is defined as

\[
\mathrm{MSE}
=
\frac{1}{T}
\sum_{t=1}^{T}
(\hat h_t-h_{\text{true}})^2.
\]

MSE penalizes large estimation errors more heavily than MAE. This makes it particularly useful for examining the effect of impulsive noise.

### 4.3 Bit Error Rate

BER measures the proportion of incorrectly detected bits:

\[
\mathrm{BER}
=
\frac{N_{\mathrm{errors}}}{N_{\mathrm{bits}}}.
\]

The BER experiment uses 10,000 transmitted BPSK bits. A bit is detected by examining the sign of the equalized received signal.

---

## 5. Simulation Setup

The project is implemented in Python using NumPy for numerical calculations and Matplotlib for visualization.

The simulation includes the following experiments:

| Experiment | Main purpose |
|---|---|
| Noise-free validation | Verify the LS implementation |
| Gaussian noise sweep | Examine the effect of noise strength |
| Impulsive-noise comparison | Compare LS, Huber, and Median |
| Monte Carlo evaluation | Compare average estimation errors |
| BER evaluation | Measure bit detection errors |
| BER versus noise strength | Study detection performance at different noise levels |
| Pilot-length experiment | Examine the effect of the number of pilots |
| Huber threshold sensitivity | Study the effect of \(\delta\) |
| MSE versus SNR | Compare estimation accuracy across Gaussian SNR values |
| MSE versus impulse probability | Examine robustness to increasing impulsive-noise occurrence |

Fixed random seeds are used in the experiments to improve reproducibility. In the main Monte Carlo comparison, all three estimators use the same observations within each trial, providing a fair comparison.

---

## 6. Results and Discussion

### 6.1 Noise-Free Validation

The LS implementation is first tested using a received signal without noise:

\[
y_k=h_{\text{true}}x_k.
\]

Under this condition, the estimator should recover the true channel coefficient, apart from negligible floating-point numerical error.

This experiment provides a basic validation of the estimator implementation.

### 6.2 Effect of Gaussian Noise Strength

The LS estimator is evaluated at Gaussian noise standard deviations of 0.01, 0.05, 0.10, 0.20, and 0.50. Each setting is evaluated over 500 trials.

The measured results are:

| Noise standard deviation | Mean absolute error | MSE |
|---:|---:|---:|
| 0.01 | 0.000780 | 0.000001 |
| 0.05 | 0.004081 | 0.000026 |
| 0.10 | 0.008417 | 0.000109 |
| 0.20 | 0.015945 | 0.000394 |
| 0.50 | 0.038938 | 0.002494 |

Both error metrics increase as the Gaussian noise becomes stronger.

At a standard deviation of 0.01, the mean absolute error is 0.000780. When the standard deviation increases to 0.50, the error rises to 0.038938.

This result demonstrates that the LS estimator becomes less accurate as the noise level increases.

### 6.3 Comparison Under Impulsive Noise

The impulsive-noise experiment uses 100 pilot symbols, Gaussian noise with standard deviation 0.1, an impulsive-noise probability of 0.05, and an impulsive-noise standard deviation of 2.0.

The observed channel estimates are:

| Method | Estimated channel | Absolute error |
|---|---:|---:|
| LS | 0.7263 | 0.0737 |
| Huber | 0.7913 | 0.0087 |
| Median | 0.7910 | 0.0090 |

The true channel coefficient is 0.8.

LS produces a larger estimation error because its estimate is more strongly affected by the large noise samples. Huber and Median provide estimates much closer to the true coefficient in this trial.

The results illustrate the potential advantage of robust estimation when impulsive disturbances are present.

### 6.4 Monte Carlo Comparison

A Monte Carlo experiment is performed using 500 trials, with 100 pilot symbols per trial. The Gaussian noise standard deviation is 0.1, the impulsive-noise probability is 0.05, and the impulsive-noise standard deviation is 2.0.

The recorded results are:

| Method | MAE | MSE |
|---|---:|---:|
| LS | 0.036628 | 0.002276 |
| Huber | 0.008728 | 0.000124 |
| Median | 0.010414 | 0.000170 |

Huber achieves the lowest MAE and MSE among the three methods in this experiment.

Compared with LS, Huber reduces MAE from 0.036628 to 0.008728 and MSE from 0.002276 to 0.000124.

Median also substantially improves on LS, although its errors are slightly higher than those of Huber in this experiment.

These results support the use of robust estimators when a small proportion of observations may contain large disturbances.

### 6.5 BER Evaluation

The BER experiment transmits 10,000 BPSK bits over the channel. The Gaussian noise standard deviation is 0.1, the impulsive-noise probability is 0.01, and the impulsive-noise standard deviation is 2.0.

The measured results are:

| Method | BER | Number of bit errors |
|---|---:|---:|
| LS | 0.0032 | 32 |
| Huber | 0.0032 | 32 |
| Median | 0.0032 | 32 |

All three methods produce the same BER in this experiment.

This result requires careful interpretation. The channel is a real-valued positive scalar, and all three estimated channel coefficients are positive. Dividing the received signal by any of these positive estimates does not change the sign used by the BPSK detector.

Therefore, all three detectors make identical bit decisions. The equal BER values do not indicate that the channel estimators have equal accuracy.

The estimation-error metrics are more informative for comparing the three estimators under this particular system model.

### 6.6 BER Versus Gaussian Noise Strength

The project also evaluates BER at several Gaussian noise standard deviations: 0.05, 0.10, 0.20, 0.30, and 0.50. The impulsive-noise probability remains 0.01, and the impulsive-noise standard deviation remains 2.0.

The recorded results are:

| Gaussian noise standard deviation | BER | Number of bit errors |
|---:|---:|---:|
| 0.05 | 0.0035 | 35 |
| 0.10 | 0.0040 | 40 |
| 0.20 | 0.0042 | 42 |
| 0.30 | 0.0080 | 80 |
| 0.50 | 0.0621 | 621 |

BER generally increases as the Gaussian noise becomes stronger. The increase is particularly pronounced at a standard deviation of 0.50.

The results show how stronger noise can reduce the reliability of BPSK detection.

### 6.7 Effect of Pilot Length

The pilot-length experiment considers 10, 20, 50, 100, 200, and 500 pilot symbols. Each length is evaluated over 200 trials with the same noise settings used in the main impulsive-noise experiments.

The measured MAE values are:

| Pilot symbols | LS MAE | Huber MAE | Median MAE |
|---:|---:|---:|---:|
| 10 | 0.08664 | 0.02939 | 0.03159 |
| 20 | 0.06571 | 0.02080 | 0.02500 |
| 50 | 0.04760 | 0.01151 | 0.01422 |
| 100 | 0.03404 | 0.00952 | 0.01118 |
| 200 | 0.02647 | 0.00693 | 0.00787 |
| 500 | 0.01538 | 0.00384 | 0.00481 |

For all three estimators, the MAE decreases as the number of pilot symbols increases.

The larger pilot set provides more observations from which to estimate the channel. Huber and Median consistently achieve lower MAE than LS under the tested impulsive-noise conditions.

Among the methods, Huber produces the lowest MAE at every pilot length in this experiment.

### 6.8 Sensitivity to the Huber Threshold

The Huber threshold controls how strongly large residuals are down-weighted. The project evaluates the values 0.5, 1.0, 1.345, 2.0, and 3.0 over 200 trials.

The recorded results are:

| Huber threshold \(\delta\) | Mean absolute error |
|---:|---:|
| 0.5 | 0.009388 |
| 1.0 | 0.008316 |
| 1.345 | 0.008151 |
| 2.0 | 0.008273 |
| 3.0 | 0.009061 |

The lowest MAE in this experiment occurs at \(\delta=1.345\).

The results indicate that the threshold affects estimation accuracy. A threshold that is too small or too large may perform less effectively under the selected noise conditions.

The value 1.345 performs well in this experiment, but it should not be interpreted as universally optimal for every channel or noise distribution.

### 6.9 MSE Versus Gaussian SNR

The project evaluates MSE at Gaussian SNR values of -5, 0, 5, 10, 15, and 20 dB. Each point is evaluated over 500 trials using 100 pilot symbols.

The impulsive-noise probability is fixed at 0.05, and the impulsive-noise standard deviation is fixed at 2.0.

The measured results are:

| Gaussian SNR (dB) | LS MSE | Huber MSE | Median MSE |
|---:|---:|---:|---:|
| -5 | 0.021853 | 0.022174 | 0.031996 |
| 0 | 0.008281 | 0.007770 | 0.011623 |
| 5 | 0.004515 | 0.002743 | 0.003649 |
| 10 | 0.002438 | 0.000750 | 0.001025 |
| 15 | 0.002440 | 0.000241 | 0.000318 |
| 20 | 0.002156 | 0.000078 | 0.000113 |

At low Gaussian SNR, the performance differences are less consistent. At -5 dB, LS has slightly lower MSE than Huber, while Median has the highest MSE.

As Gaussian SNR increases, Huber and Median achieve substantially lower MSE than LS. At 20 dB, Huber provides the lowest MSE among the three estimators.

**Interpretation:** The SNR in this experiment describes the signal power relative to the Gaussian noise power. Because impulsive noise is held fixed, it does not represent the signal-to-total-noise ratio. The fixed impulsive component can continue to affect estimation error even at high Gaussian SNR.

### 6.10 MSE Versus Impulsive-Noise Probability

The final experiment investigates the effect of impulsive-noise probability on estimation accuracy. The probability values are 0, 0.01, 0.03, 0.05, 0.10, and 0.20. Each setting uses 500 trials with 100 pilot symbols.

Gaussian noise has standard deviation 0.1, and impulsive noise has standard deviation 2.0.

The recorded results are:

| Impulsive-noise probability | LS MSE | Huber MSE | Median MSE |
|---:|---:|---:|---:|
| 0.00 | 0.000102 | 0.000108 | 0.000165 |
| 0.01 | 0.000496 | 0.000114 | 0.000163 |
| 0.03 | 0.001314 | 0.000121 | 0.000187 |
| 0.05 | 0.002183 | 0.000132 | 0.000187 |
| 0.10 | 0.004093 | 0.000167 | 0.000203 |
| 0.20 | 0.008930 | 0.000220 | 0.000226 |

As the probability of impulsive noise increases, the MSE of LS rises substantially. Its MSE increases from 0.000102 when no impulses are present to 0.008930 at a probability of 0.20.

Huber maintains a much lower MSE across the tested probabilities. Median also remains substantially more accurate than LS when impulsive noise is present.

At zero impulsive-noise probability, LS has slightly lower MSE than Huber and Median. This is consistent with the fact that robust methods are not guaranteed to outperform LS under every noise condition.

The results demonstrate the importance of selecting an estimator based on the expected noise environment.

---

## 7. Overall Discussion

The experiments provide several important observations.

First, the performance of LS depends on the noise conditions. It works well when disturbances are relatively small, but its estimation error can increase substantially in the presence of impulsive outliers.

Second, Huber estimation provides strong performance in the impulsive-noise experiments. Its combination of quadratic and linear loss behavior reduces the influence of unusually large residuals.

Third, Median-based estimation is also robust to large disturbances and consistently outperforms LS in the main pilot-length and Monte Carlo comparisons.

Fourth, increasing the number of pilot symbols generally improves estimation accuracy for all three methods. This improvement is particularly useful in environments where impulsive disturbances can significantly corrupt individual observations.

Finally, BER must be interpreted according to the system model. In the present real-valued, positive-channel model, positive channel estimates lead to identical sign-based BPSK decisions. As a result, BER alone does not reveal the differences in channel-estimation accuracy.

---

## 8. Limitations

The project uses a simplified communication model. The channel coefficient is real-valued and constant, and the simulations do not include time-varying fading or complex-valued channel coefficients.

The BER experiment uses sign-based BPSK detection with a positive scalar channel. This design makes the decisions identical when all estimated channel coefficients are positive. Therefore, the BER results do not fully demonstrate the impact of estimation accuracy on detection performance.

The experiments also use particular values for the Gaussian noise level, impulsive-noise probability, and impulse amplitude. The relative performance of the estimators may change under other noise distributions and channel conditions.

In the SNR experiment, the reported SNR refers specifically to Gaussian noise; impulsive noise is kept fixed. Consequently, the SNR should not be interpreted as the ratio of signal power to the total power of all noise components.

---

## 9. Conclusion

This project investigated robust channel estimation in a simulated BPSK digital communication system by comparing LS, Huber, and Median estimators.

The results show that LS is simple and effective under relatively mild noise conditions, but it is more sensitive to impulsive disturbances. Huber and Median provide more accurate channel estimates in the main impulsive-noise experiments.

In the 500-trial Monte Carlo comparison, Huber achieved an MAE of 0.008728 and an MSE of 0.000124, compared with 0.036628 and 0.002276 for LS. The pilot-length experiment also showed that estimation errors generally decrease as more pilot symbols are used.

The SNR and impulsive-probability experiments further demonstrated that estimator performance depends on the noise environment. Huber was particularly effective under the tested impulsive-noise conditions, although LS performed slightly better at the lowest Gaussian SNR and when no impulsive noise was present in the corresponding experiments.

The BER experiment produced identical BER values for all three methods because of the positive real-valued channel and sign-based BPSK detector. This limitation emphasizes the need to use appropriate metrics when evaluating channel-estimation algorithms.

Overall, the results support robust channel estimation as a useful approach for improving estimation accuracy in communication systems affected by impulsive noise.

---

## References

1. Huber, P. J. (1964). Robust Estimation of a Location Parameter. *The Annals of Mathematical Statistics*, 35(1), 73–101.
2. Kay, S. M. (1993). *Fundamentals of Statistical Signal Processing: Estimation Theory*. Prentice Hall.
3. Proakis, J. G., and Salehi, M. (2008). *Digital Communications*. McGraw-Hill.
4. NumPy documentation. Numerical computing with Python.
5. Matplotlib documentation. Visualization with Python.