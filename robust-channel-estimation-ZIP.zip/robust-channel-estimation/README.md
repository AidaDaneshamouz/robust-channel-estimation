# Robust Channel Estimation in Digital Communications

## Overview

This project investigates channel estimation methods in a simple BPSK digital communication system under Gaussian and impulsive noise.

Three channel estimation methods are implemented and evaluated:

- Least Squares (LS)
- Huber robust estimation using an iterative reweighted least squares approach
- Median-based estimation

The experiments compare estimation accuracy and investigate the effects of impulsive noise, pilot length, and the Huber threshold parameter.

## Channel Model

The real-valued flat-fading channel is modeled as:

`y_k = h x_k + n_k`

where:

- `h` is the unknown channel coefficient.
- `x_k` is a known BPSK pilot symbol.
- `y_k` is the received pilot observation.
- `n_k` is additive noise.

The true channel coefficient used in the baseline experiments is `h = 0.8`.

## Implemented Methods

### Least Squares

The LS estimator minimizes the squared residual error:

`h_hat = sum(x_k * y_k) / sum(x_k ** 2)`

### Huber Estimator

The Huber estimator reduces the influence of large residuals through robust weighting and iterative updates.

### Median Estimator

The median-based estimate is calculated as:

`h_hat = median(y_k / x_k)`

## Experiments

The notebook includes:

1. A noise-free LS baseline test.
2. LS estimation under different Gaussian noise levels.
3. A comparison of LS, Huber, and Median under impulsive noise.
4. Monte Carlo estimation-error comparisons.
5. BPSK bit-error-rate (BER) experiments.
6. Estimation-error analysis for different pilot lengths.
7. Sensitivity analysis of the Huber threshold parameter.

## Main Findings

Under the tested impulsive-noise conditions, the Huber estimator achieved lower mean absolute error and mean squared error than LS and Median.

Increasing the pilot length reduced the observed mean absolute estimation error for all three estimators in the experiments.

The tested Huber threshold value of `delta = 1.345` produced the lowest mean absolute error among the five threshold values evaluated in the sensitivity experiment.

In the current positive real-valued channel model, the sign-based BPSK detector produced identical BER values for all three positive channel estimates. Therefore, lower channel-estimation error did not necessarily translate into lower BER.

These findings apply to the tested simulation settings and should not be interpreted as universal performance guarantees.

## Requirements

- Python 3
- NumPy
- Matplotlib

Install dependencies with:

`pip install -r requirements.txt`

## How to Run

1. Open `robust_channel_estimation.ipynb` in Visual Studio Code.
2. Select a Python environment with the required dependencies installed.
3. Run the notebook cells from top to bottom.
4. Review the printed results and generated plots.

For reproducibility, the experiments use fixed random seeds.

## Limitations

The current model uses a real-valued scalar channel coefficient and BPSK signaling. The BER experiment uses a sign-based detector, so positive channel-estimate scaling does not change the detected bit signs.

The experiments do not establish that robust estimators always outperform LS. Performance depends on the noise distribution, noise parameters, pilot length, and estimator configuration.